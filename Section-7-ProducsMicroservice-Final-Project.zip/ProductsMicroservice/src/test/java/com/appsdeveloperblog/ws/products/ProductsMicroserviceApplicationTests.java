package com.appsdeveloperblog.ws.products;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
